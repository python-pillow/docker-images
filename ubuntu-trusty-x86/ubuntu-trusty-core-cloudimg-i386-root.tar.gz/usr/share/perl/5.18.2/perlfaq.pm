package perlfaq;
{
  $perlfaq::VERSION = '5.0150042';
}

0; # not is it supposed to be loaded
